import { useState } from 'react'
import { Card, Input } from './components'
import { CategorySelection } from './patterns/CategorySelection'
export function App() {
  const [presentation, setPresentation] = useState('default')
  const [theme, setTheme] = useState('light')
  return <main data-theme={theme} data-presentation={presentation} style={{minHeight:'100vh',background:'var(--m8-background-canvas)',color:'var(--m8-text-primary)',padding:'var(--m8-layout-gutter)',fontFamily:'var(--m8-presentation-font-interface)'}}>
    <div style={{maxWidth:720,margin:'auto',display:'grid',gap:24}}>
      <h1 style={{fontFamily:'var(--m8-presentation-font-display)'}}>Start with Modern8-bits</h1>
      <label>Presentation <select value={presentation} onChange={event=>setPresentation(event.target.value)}><option value="default">Default</option><option value="low-fidelity">Low-fidelity</option></select></label>
      <label>Appearance <select value={theme} onChange={event=>setTheme(event.target.value)}><option value="light">Light</option><option value="dark">Dark</option></select></label>
      <Card title="Your first form"><Input label="Project name" hint="Change modes: your entry stays in place." /></Card>
      <CategorySelection />
    </div>
  </main>
}
