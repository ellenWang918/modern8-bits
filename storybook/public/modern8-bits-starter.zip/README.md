# Modern8-bits starter

Use Node.js 22 or newer. Run `npm install`, then `npm run dev`. Choose presentation and appearance in the UI. Read USAGE.md before extending the app. Run `npm run build` before sharing. Fonts load from Google Fonts with system fallbacks. The examples have no backend or persistent storage.
